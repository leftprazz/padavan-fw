@dir /app/main
@brief app/main: Entry point for tor.
