/* Added for Tor. */
#include "lib/cc/torint.h"
#define crypto_uint64 uint64_t
