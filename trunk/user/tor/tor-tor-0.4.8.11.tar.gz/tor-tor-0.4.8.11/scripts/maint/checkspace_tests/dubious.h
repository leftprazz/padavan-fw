
// no guards.

int foo(int);
