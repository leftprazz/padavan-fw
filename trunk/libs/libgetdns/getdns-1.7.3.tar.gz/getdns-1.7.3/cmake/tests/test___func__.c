int main (int ac, char *av[])
{
	char *s = __func__;
}
